package net.mcreator.buttermod.client.renderer;

import net.mcreator.buttermod.entity.ButterzombieEntity;
import net.minecraft.client.animation.definitions.CreakingAnimation;
import net.minecraft.client.model.CreeperModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.client.renderer.entity.state.CreeperRenderState;
import net.minecraft.resources.ResourceLocation;

public class ButterzombieRenderer extends MobRenderer<ButterzombieEntity, CreeperRenderState, CreeperModel> {
   private ButterzombieEntity entity = null;

   public ButterzombieRenderer(Context context) {
      super(context, new ButterzombieRenderer.AnimatedModel(context.bakeLayer(ModelLayers.CREEPER)), 0.5F);
   }

   public CreeperRenderState createRenderState() {
      return new CreeperRenderState();
   }

   public void extractRenderState(ButterzombieEntity entity, CreeperRenderState state, float partialTicks) {
      super.extractRenderState(entity, state, partialTicks);
      this.entity = entity;
      if (this.model instanceof ButterzombieRenderer.AnimatedModel) {
         ((ButterzombieRenderer.AnimatedModel)this.model).setEntity(entity);
      }

   }

   public ResourceLocation getTextureLocation(CreeperRenderState state) {
      return ResourceLocation.parse("buttermod:textures/entities/gold_creeper_texture.png");
   }

   private static final class AnimatedModel extends CreeperModel {
      private ButterzombieEntity entity = null;

      public AnimatedModel(ModelPart root) {
         super(root);
      }

      public void setEntity(ButterzombieEntity entity) {
         this.entity = entity;
      }

      public void setupAnim(CreeperRenderState state) {
         this.root().getAllParts().forEach(ModelPart::resetPose);
         this.animateWalk(CreakingAnimation.CREAKING_WALK, state.walkAnimationPos, state.walkAnimationSpeed, 1.0F, 1.0F);
         super.setupAnim(state);
      }
   }
}
