package net.mcreator.buttermod.block;

import com.mojang.logging.LogUtils;
import java.util.Optional;
import java.util.Set;
import javax.annotation.Nullable;
import net.mcreator.buttermod.world.teleporter.ButterdemensionPortalShape;
import net.mcreator.buttermod.world.teleporter.ButterdemensionTeleporter;
import net.minecraft.BlockUtil;
import net.minecraft.BlockUtil.FoundRectangle;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Direction.Axis;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.Relative;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.ScheduledTickAccess;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.NetherPortalBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Portal.Transition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.border.WorldBorder;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.level.portal.TeleportTransition;
import net.minecraft.world.level.portal.TeleportTransition.PostTeleportTransition;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.slf4j.Logger;

public class ButterdemensionPortalBlock extends NetherPortalBlock {
   private static final Logger LOGGER = LogUtils.getLogger();

   public static void portalSpawn(Level world, BlockPos pos) {
      Optional<ButterdemensionPortalShape> optional = ButterdemensionPortalShape.findEmptyPortalShape(world, pos, Axis.X);
      if (optional.isPresent()) {
         ((ButterdemensionPortalShape)optional.get()).createPortalBlocks(world);
      }

   }

   public ButterdemensionPortalBlock(Properties properties) {
      super(properties.noCollission().randomTicks().pushReaction(PushReaction.BLOCK).strength(-1.0F).sound(SoundType.GLASS).lightLevel((s) -> {
         return 0;
      }).noLootTable());
   }

   private ButterdemensionTeleporter getTeleporter(ServerLevel level) {
      return new ButterdemensionTeleporter(level);
   }

   protected BlockState updateShape(BlockState p_54928_, LevelReader p_374413_, ScheduledTickAccess p_374339_, BlockPos p_54932_, Direction p_54929_, BlockPos p_54933_, BlockState p_54930_, RandomSource p_374242_) {
      Axis direction$axis = p_54929_.getAxis();
      Axis direction$axis1 = (Axis)p_54928_.getValue(AXIS);
      boolean flag = direction$axis1 != direction$axis && direction$axis.isHorizontal();
      return !flag && !p_54930_.is(this) && !ButterdemensionPortalShape.findAnyShape(p_374413_, p_54932_, direction$axis1).isComplete() ? Blocks.AIR.defaultBlockState() : super.updateShape(p_54928_, p_374413_, p_374339_, p_54932_, p_54929_, p_54933_, p_54930_, p_374242_);
   }

   @Nullable
   public TeleportTransition getPortalDestination(ServerLevel p_350444_, Entity p_350334_, BlockPos p_350764_) {
      ResourceKey<Level> resourcekey = p_350444_.dimension() == ResourceKey.create(Registries.DIMENSION, ResourceLocation.parse("buttermod:butterdemension")) ? Level.OVERWORLD : ResourceKey.create(Registries.DIMENSION, ResourceLocation.parse("buttermod:butterdemension"));
      ServerLevel serverlevel = p_350444_.getServer().getLevel(resourcekey);
      if (serverlevel == null) {
         return null;
      } else {
         boolean flag = serverlevel.dimension() == ResourceKey.create(Registries.DIMENSION, ResourceLocation.parse("buttermod:butterdemension"));
         WorldBorder worldborder = serverlevel.getWorldBorder();
         double d0 = DimensionType.getTeleportationScale(p_350444_.dimensionType(), serverlevel.dimensionType());
         BlockPos blockpos = worldborder.clampToBounds(p_350334_.getX() * d0, p_350334_.getY(), p_350334_.getZ() * d0);
         return this.getExitPortal(serverlevel, p_350334_, p_350764_, blockpos, flag, worldborder);
      }
   }

   @Nullable
   private TeleportTransition getExitPortal(ServerLevel p_350564_, Entity p_350493_, BlockPos p_350379_, BlockPos p_350747_, boolean p_350326_, WorldBorder p_350718_) {
      Optional<BlockPos> optional = this.getTeleporter(p_350564_).findClosestPortalPosition(p_350747_, p_350326_, p_350718_);
      FoundRectangle blockutil$foundrectangle;
      PostTeleportTransition teleporttransition$postteleporttransition;
      if (optional.isPresent()) {
         BlockPos blockpos = (BlockPos)optional.get();
         BlockState blockstate = p_350564_.getBlockState(blockpos);
         blockutil$foundrectangle = BlockUtil.getLargestRectangleAround(blockpos, (Axis)blockstate.getValue(BlockStateProperties.HORIZONTAL_AXIS), 21, Axis.Y, 21, (p_351970_) -> {
            return p_350564_.getBlockState(p_351970_) == blockstate;
         });
         teleporttransition$postteleporttransition = TeleportTransition.PLAY_PORTAL_SOUND.then((p_351967_) -> {
            p_351967_.placePortalTicket(blockpos);
         });
      } else {
         Axis direction$axis = (Axis)p_350493_.level().getBlockState(p_350379_).getOptionalValue(AXIS).orElse(Axis.X);
         Optional<FoundRectangle> optional1 = this.getTeleporter(p_350564_).createPortal(p_350747_, direction$axis);
         if (optional1.isEmpty()) {
            LOGGER.error("Unable to create a portal, likely target out of worldborder");
            return null;
         }

         blockutil$foundrectangle = (FoundRectangle)optional1.get();
         teleporttransition$postteleporttransition = TeleportTransition.PLAY_PORTAL_SOUND.then(TeleportTransition.PLACE_PORTAL_TICKET);
      }

      return getDimensionTransitionFromExit(p_350493_, p_350379_, blockutil$foundrectangle, p_350564_, teleporttransition$postteleporttransition);
   }

   private static TeleportTransition getDimensionTransitionFromExit(Entity p_350906_, BlockPos p_350376_, FoundRectangle p_350428_, ServerLevel p_350928_, PostTeleportTransition p_379530_) {
      BlockState blockstate = p_350906_.level().getBlockState(p_350376_);
      Axis direction$axis;
      Vec3 vec3;
      if (blockstate.hasProperty(BlockStateProperties.HORIZONTAL_AXIS)) {
         direction$axis = (Axis)blockstate.getValue(BlockStateProperties.HORIZONTAL_AXIS);
         FoundRectangle blockutil$foundrectangle = BlockUtil.getLargestRectangleAround(p_350376_, direction$axis, 21, Axis.Y, 21, (p_351016_) -> {
            return p_350906_.level().getBlockState(p_351016_) == blockstate;
         });
         vec3 = p_350906_.getRelativePortalPosition(direction$axis, blockutil$foundrectangle);
      } else {
         direction$axis = Axis.X;
         vec3 = new Vec3(0.5D, 0.0D, 0.0D);
      }

      return createDimensionTransition(p_350928_, p_350428_, direction$axis, vec3, p_350906_, p_379530_);
   }

   private static TeleportTransition createDimensionTransition(ServerLevel p_350955_, FoundRectangle p_350865_, Axis p_351013_, Vec3 p_351020_, Entity p_350578_, PostTeleportTransition p_379531_) {
      BlockPos blockpos = p_350865_.minCorner;
      BlockState blockstate = p_350955_.getBlockState(blockpos);
      Axis direction$axis = (Axis)blockstate.getOptionalValue(BlockStateProperties.HORIZONTAL_AXIS).orElse(Axis.X);
      double d0 = (double)p_350865_.axis1Size;
      double d1 = (double)p_350865_.axis2Size;
      EntityDimensions entitydimensions = p_350578_.getDimensions(p_350578_.getPose());
      int i = p_351013_ == direction$axis ? 0 : 90;
      double d2 = (double)entitydimensions.width() / 2.0D + (d0 - (double)entitydimensions.width()) * p_351020_.x();
      double d3 = (d1 - (double)entitydimensions.height()) * p_351020_.y();
      double d4 = 0.5D + p_351020_.z();
      boolean flag = direction$axis == Axis.X;
      Vec3 vec3 = new Vec3((double)blockpos.getX() + (flag ? d2 : d4), (double)blockpos.getY() + d3, (double)blockpos.getZ() + (flag ? d4 : d2));
      Vec3 vec31 = ButterdemensionPortalShape.findCollisionFreePosition(vec3, p_350955_, p_350578_, entitydimensions);
      return new TeleportTransition(p_350955_, vec31, Vec3.ZERO, (float)i, 0.0F, Relative.union(new Set[]{Relative.DELTA, Relative.ROTATION}), p_379531_);
   }

   public int getPortalTransitionTime(ServerLevel world, Entity entity) {
      return 0;
   }

   public Transition getLocalTransition() {
      return Transition.NONE;
   }

   public void randomTick(BlockState blockstate, ServerLevel world, BlockPos pos, RandomSource random) {
   }

   @OnlyIn(Dist.CLIENT)
   public void animateTick(BlockState state, Level world, BlockPos pos, RandomSource random) {
      for(int i = 0; i < 4; ++i) {
         double px = (double)((float)pos.getX() + random.nextFloat());
         double py = (double)((float)pos.getY() + random.nextFloat());
         double pz = (double)((float)pos.getZ() + random.nextFloat());
         double vx = ((double)random.nextFloat() - 0.5D) / 2.0D;
         double vy = ((double)random.nextFloat() - 0.5D) / 2.0D;
         double vz = ((double)random.nextFloat() - 0.5D) / 2.0D;
         int j = random.nextInt(4) - 1;
         if (world.getBlockState(pos.west()).getBlock() != this && world.getBlockState(pos.east()).getBlock() != this) {
            px = (double)pos.getX() + 0.5D + 0.25D * (double)j;
            vx = (double)(random.nextFloat() * 2.0F * (float)j);
         } else {
            pz = (double)pos.getZ() + 0.5D + 0.25D * (double)j;
            vz = (double)(random.nextFloat() * 2.0F * (float)j);
         }

         world.addParticle(ParticleTypes.PORTAL, px, py, pz, vx, vy, vz);
      }

      if (random.nextInt(110) == 0) {
         world.playLocalSound((double)pos.getX() + 0.5D, (double)pos.getY() + 0.5D, (double)pos.getZ() + 0.5D, (SoundEvent)BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("block.honey_block.slide")), SoundSource.BLOCKS, 0.5F, random.nextFloat() * 0.4F + 0.8F, false);
      }

   }
}
