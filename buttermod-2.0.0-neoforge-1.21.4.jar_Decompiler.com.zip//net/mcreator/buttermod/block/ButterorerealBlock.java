package net.mcreator.buttermod.block;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;

public class ButterorerealBlock extends Block {
   public ButterorerealBlock(Properties properties) {
      super(properties.sound(SoundType.HONEY_BLOCK).strength(1.0F, 10.0F).requiresCorrectToolForDrops());
   }

   public int getLightBlock(BlockState state) {
      return 15;
   }
}
