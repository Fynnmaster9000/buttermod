package net.mcreator.buttermod.potion;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation;

public class ButtereffectMobEffect extends MobEffect {
   public ButtereffectMobEffect() {
      super(MobEffectCategory.NEUTRAL, -256);
      this.addAttributeModifier(Attributes.LUCK, ResourceLocation.fromNamespaceAndPath("buttermod", "effect.buttereffect_0"), 255.0D, Operation.ADD_VALUE);
   }
}
