package net.mcreator.buttermod.init;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.alchemy.Potion;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ButtermodModPotions {
   public static final DeferredRegister<Potion> REGISTRY;
   public static final DeferredHolder<Potion, Potion> POTIONOFBUTTER;

   static {
      REGISTRY = DeferredRegister.create(Registries.POTION, "buttermod");
      POTIONOFBUTTER = REGISTRY.register("potionofbutter", () -> {
         return new Potion("potionofbutter", new MobEffectInstance[]{new MobEffectInstance(ButtermodModMobEffects.BUTTEREFFECT, 3600, 255, false, true), new MobEffectInstance(MobEffects.GLOWING, 3600, 255, false, true)});
      });
   }
}
