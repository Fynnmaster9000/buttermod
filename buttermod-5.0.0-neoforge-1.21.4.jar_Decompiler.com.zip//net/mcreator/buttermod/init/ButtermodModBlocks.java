package net.mcreator.buttermod.init;

import java.util.function.Function;
import net.mcreator.buttermod.block.ButteroreBlock;
import net.mcreator.buttermod.block.ButterorerealBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredRegister.Blocks;

public class ButtermodModBlocks {
   public static final Blocks REGISTRY = DeferredRegister.createBlocks("buttermod");
   public static final DeferredBlock<Block> BUTTER_BLOCK = register("butter_block", ButteroreBlock::new);
   public static final DeferredBlock<Block> BUTTEROREREAL = register("butterorereal", ButterorerealBlock::new);

   private static <B extends Block> DeferredBlock<B> register(String name, Function<Properties, ? extends B> supplier) {
      return REGISTRY.registerBlock(name, supplier, Properties.of());
   }
}
