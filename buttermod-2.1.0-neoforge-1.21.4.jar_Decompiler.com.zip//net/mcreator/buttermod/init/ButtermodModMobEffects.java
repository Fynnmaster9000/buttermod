package net.mcreator.buttermod.init;

import net.mcreator.buttermod.potion.ButtereffectMobEffect;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.effect.MobEffect;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ButtermodModMobEffects {
   public static final DeferredRegister<MobEffect> REGISTRY;
   public static final DeferredHolder<MobEffect, MobEffect> BUTTEREFFECT;

   static {
      REGISTRY = DeferredRegister.create(Registries.MOB_EFFECT, "buttermod");
      BUTTEREFFECT = REGISTRY.register("buttereffect", () -> {
         return new ButtereffectMobEffect();
      });
   }
}
