package net.mcreator.buttermod.world.teleporter;

import com.google.common.collect.ImmutableSet;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Stream;
import net.mcreator.buttermod.init.ButtermodModBlocks;
import net.minecraft.BlockUtil.FoundRectangle;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Holder;
import net.minecraft.core.Vec3i;
import net.minecraft.core.BlockPos.MutableBlockPos;
import net.minecraft.core.Direction.Axis;
import net.minecraft.core.Direction.AxisDirection;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.ai.village.poi.PoiManager;
import net.minecraft.world.entity.ai.village.poi.PoiRecord;
import net.minecraft.world.entity.ai.village.poi.PoiType;
import net.minecraft.world.entity.ai.village.poi.PoiManager.Occupancy;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.NetherPortalBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.border.WorldBorder;
import net.minecraft.world.level.levelgen.Heightmap.Types;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.common.EventBusSubscriber.Bus;
import net.neoforged.neoforge.registries.RegisterEvent;

@EventBusSubscriber(
   bus = Bus.MOD
)
public class ButterdemensionTeleporter {
   public static Holder<PoiType> poi = null;
   private final ServerLevel level;

   @SubscribeEvent
   public static void registerPointOfInterest(RegisterEvent event) {
      event.register(Registries.POINT_OF_INTEREST_TYPE, (registerHelper) -> {
         PoiType poiType = new PoiType(ImmutableSet.copyOf(((Block)ButtermodModBlocks.BUTTERDEMENSION_PORTAL.get()).getStateDefinition().getPossibleStates()), 0, 1);
         registerHelper.register(ResourceLocation.parse("buttermod:butterdemension_portal"), poiType);
         poi = BuiltInRegistries.POINT_OF_INTEREST_TYPE.wrapAsHolder(poiType);
      });
   }

   public ButterdemensionTeleporter(ServerLevel level) {
      this.level = level;
   }

   public Optional<BlockPos> findClosestPortalPosition(BlockPos p_352378_, boolean p_352309_, WorldBorder p_352374_) {
      PoiManager poimanager = this.level.getPoiManager();
      int i = p_352309_ ? 16 : 128;
      poimanager.ensureLoadedAndValid(this.level, p_352378_, i);
      Stream var10000 = poimanager.getInSquare((p_230634_) -> {
         return p_230634_.is((ResourceKey)poi.unwrapKey().get());
      }, p_352378_, i, Occupancy.ANY).map(PoiRecord::getPos);
      Objects.requireNonNull(p_352374_);
      return var10000.filter(p_352374_::isWithinBounds).filter((p_352047_) -> {
         return this.level.getBlockState(p_352047_).hasProperty(BlockStateProperties.HORIZONTAL_AXIS);
      }).min(Comparator.comparingDouble((p_352046_) -> {
         return p_352046_.distSqr(p_352378_);
      }).thenComparingInt(Vec3i::getY));
   }

   public Optional<FoundRectangle> createPortal(BlockPos p_77667_, Axis p_77668_) {
      Direction direction = Direction.get(AxisDirection.POSITIVE, p_77668_);
      double d0 = -1.0D;
      BlockPos blockpos = null;
      double d1 = -1.0D;
      BlockPos blockpos1 = null;
      WorldBorder worldborder = this.level.getWorldBorder();
      int i = Math.min(this.level.getMaxY(), this.level.getMinY() + this.level.getLogicalHeight() - 1);
      int j = true;
      MutableBlockPos blockpos$mutableblockpos = p_77667_.mutable();
      Iterator var14 = BlockPos.spiralAround(p_77667_, 16, Direction.EAST, Direction.SOUTH).iterator();

      while(true) {
         MutableBlockPos blockpos$mutableblockpos1;
         int l2;
         int l;
         int j3;
         int j1;
         do {
            do {
               if (!var14.hasNext()) {
                  if (d0 == -1.0D && d1 != -1.0D) {
                     blockpos = blockpos1;
                     d0 = d1;
                  }

                  int l1;
                  int k2;
                  if (d0 == -1.0D) {
                     l1 = Math.max(this.level.getMinY() - -1, 70);
                     k2 = i - 9;
                     if (k2 < l1) {
                        return Optional.empty();
                     }

                     blockpos = (new BlockPos(p_77667_.getX() - direction.getStepX() * 1, Mth.clamp(p_77667_.getY(), l1, k2), p_77667_.getZ() - direction.getStepZ() * 1)).immutable();
                     blockpos = worldborder.clampToBounds(blockpos);
                     Direction direction1 = direction.getClockWise();

                     for(l = -1; l < 2; ++l) {
                        for(j3 = 0; j3 < 2; ++j3) {
                           for(j1 = -1; j1 < 3; ++j1) {
                              BlockState blockstate1 = j1 < 0 ? ((Block)ButtermodModBlocks.BUTTER_BLOCK.get()).defaultBlockState() : Blocks.AIR.defaultBlockState();
                              blockpos$mutableblockpos.setWithOffset(blockpos, j3 * direction.getStepX() + l * direction1.getStepX(), j1, j3 * direction.getStepZ() + l * direction1.getStepZ());
                              this.level.setBlockAndUpdate(blockpos$mutableblockpos, blockstate1);
                           }
                        }
                     }
                  }

                  for(l1 = -1; l1 < 3; ++l1) {
                     for(k2 = -1; k2 < 4; ++k2) {
                        if (l1 == -1 || l1 == 2 || k2 == -1 || k2 == 3) {
                           blockpos$mutableblockpos.setWithOffset(blockpos, l1 * direction.getStepX(), k2, l1 * direction.getStepZ());
                           this.level.setBlock(blockpos$mutableblockpos, ((Block)ButtermodModBlocks.BUTTER_BLOCK.get()).defaultBlockState(), 3);
                        }
                     }
                  }

                  BlockState blockstate = (BlockState)((Block)ButtermodModBlocks.BUTTERDEMENSION_PORTAL.get()).defaultBlockState().setValue(NetherPortalBlock.AXIS, p_77668_);

                  for(k2 = 0; k2 < 2; ++k2) {
                     for(l2 = 0; l2 < 3; ++l2) {
                        blockpos$mutableblockpos.setWithOffset(blockpos, k2 * direction.getStepX(), l2, k2 * direction.getStepZ());
                        this.level.setBlock(blockpos$mutableblockpos, blockstate, 18);
                        this.level.getPoiManager().add(blockpos$mutableblockpos, poi);
                     }
                  }

                  return Optional.of(new FoundRectangle(blockpos.immutable(), 2, 3));
               }

               blockpos$mutableblockpos1 = (MutableBlockPos)var14.next();
               l2 = Math.min(i, this.level.getHeight(Types.MOTION_BLOCKING, blockpos$mutableblockpos1.getX(), blockpos$mutableblockpos1.getZ()));
            } while(!worldborder.isWithinBounds(blockpos$mutableblockpos1));
         } while(!worldborder.isWithinBounds(blockpos$mutableblockpos1.move(direction, 1)));

         blockpos$mutableblockpos1.move(direction.getOpposite(), 1);

         for(l = l2; l >= this.level.getMinY(); --l) {
            blockpos$mutableblockpos1.setY(l);
            if (this.canPortalReplaceBlock(blockpos$mutableblockpos1)) {
               for(j3 = l; l > this.level.getMinY() && this.canPortalReplaceBlock(blockpos$mutableblockpos1.move(Direction.DOWN)); --l) {
               }

               if (l + 4 <= i) {
                  j1 = j3 - l;
                  if (j1 <= 0 || j1 >= 3) {
                     blockpos$mutableblockpos1.setY(l);
                     if (this.canHostFrame(blockpos$mutableblockpos1, blockpos$mutableblockpos, direction, 0)) {
                        double d2 = p_77667_.distSqr(blockpos$mutableblockpos1);
                        if (this.canHostFrame(blockpos$mutableblockpos1, blockpos$mutableblockpos, direction, -1) && this.canHostFrame(blockpos$mutableblockpos1, blockpos$mutableblockpos, direction, 1) && (d0 == -1.0D || d0 > d2)) {
                           d0 = d2;
                           blockpos = blockpos$mutableblockpos1.immutable();
                        }

                        if (d0 == -1.0D && (d1 == -1.0D || d1 > d2)) {
                           d1 = d2;
                           blockpos1 = blockpos$mutableblockpos1.immutable();
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private boolean canHostFrame(BlockPos p_77662_, MutableBlockPos p_77663_, Direction p_77664_, int p_77665_) {
      Direction direction = p_77664_.getClockWise();

      for(int i = -1; i < 3; ++i) {
         for(int j = -1; j < 4; ++j) {
            p_77663_.setWithOffset(p_77662_, p_77664_.getStepX() * i + direction.getStepX() * p_77665_, j, p_77664_.getStepZ() * i + direction.getStepZ() * p_77665_);
            if (j < 0 && !this.level.getBlockState(p_77663_).isSolid()) {
               return false;
            }

            if (j >= 0 && !this.canPortalReplaceBlock(p_77663_)) {
               return false;
            }
         }
      }

      return true;
   }

   private boolean canPortalReplaceBlock(MutableBlockPos pos) {
      BlockState blockstate = this.level.getBlockState(pos);
      return blockstate.canBeReplaced() && blockstate.getFluidState().isEmpty();
   }
}
