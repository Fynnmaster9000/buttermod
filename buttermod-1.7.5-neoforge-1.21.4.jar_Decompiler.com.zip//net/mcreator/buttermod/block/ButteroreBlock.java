package net.mcreator.buttermod.block;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;

public class ButteroreBlock extends Block {
   public ButteroreBlock(Properties properties) {
      super(properties.sound(SoundType.GRAVEL).strength(1.0F, 10.0F).requiresCorrectToolForDrops());
   }

   public int getLightBlock(BlockState state) {
      return 15;
   }
}
