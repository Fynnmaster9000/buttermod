package net.mcreator.buttermod.init;

import net.mcreator.buttermod.entity.ButterzombieEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType.Builder;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.common.EventBusSubscriber.Bus;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

@EventBusSubscriber(
   bus = Bus.MOD
)
public class ButtermodModEntities {
   public static final DeferredRegister<EntityType<?>> REGISTRY;
   public static final DeferredHolder<EntityType<?>, EntityType<ButterzombieEntity>> BUTTERZOMBIE;

   private static <T extends Entity> DeferredHolder<EntityType<?>, EntityType<T>> register(String registryname, Builder<T> entityTypeBuilder) {
      return REGISTRY.register(registryname, () -> {
         return entityTypeBuilder.build(ResourceKey.create(Registries.ENTITY_TYPE, ResourceLocation.fromNamespaceAndPath("buttermod", registryname)));
      });
   }

   @SubscribeEvent
   public static void init(RegisterSpawnPlacementsEvent event) {
      ButterzombieEntity.init(event);
   }

   @SubscribeEvent
   public static void registerAttributes(EntityAttributeCreationEvent event) {
      event.put((EntityType)BUTTERZOMBIE.get(), ButterzombieEntity.createAttributes().build());
   }

   static {
      REGISTRY = DeferredRegister.create(Registries.ENTITY_TYPE, "buttermod");
      BUTTERZOMBIE = register("butterzombie", Builder.of(ButterzombieEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).sized(0.6F, 1.7F));
   }
}
