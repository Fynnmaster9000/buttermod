package net.mcreator.buttermod.block;

import net.mcreator.buttermod.init.ButtermodModFluids;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.material.FlowingFluid;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;

public class ButterfluidBlock extends LiquidBlock {
   public ButterfluidBlock(Properties properties) {
      super((FlowingFluid)ButtermodModFluids.BUTTERFLUID.get(), properties.mapColor(MapColor.WATER).strength(100.0F).noCollission().noLootTable().liquid().pushReaction(PushReaction.DESTROY).sound(SoundType.EMPTY).replaceable());
   }
}
