package net.mcreator.buttermod.init;

import net.mcreator.buttermod.fluid.ButterfluidFluid;
import net.minecraft.client.renderer.ItemBlockRenderTypes;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.material.FlowingFluid;
import net.minecraft.world.level.material.Fluid;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.common.EventBusSubscriber.Bus;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ButtermodModFluids {
   public static final DeferredRegister<Fluid> REGISTRY;
   public static final DeferredHolder<Fluid, FlowingFluid> BUTTERFLUID;
   public static final DeferredHolder<Fluid, FlowingFluid> FLOWING_BUTTERFLUID;

   static {
      REGISTRY = DeferredRegister.create(BuiltInRegistries.FLUID, "buttermod");
      BUTTERFLUID = REGISTRY.register("butterfluid", () -> {
         return new ButterfluidFluid.Source();
      });
      FLOWING_BUTTERFLUID = REGISTRY.register("flowing_butterfluid", () -> {
         return new ButterfluidFluid.Flowing();
      });
   }

   @EventBusSubscriber(
      bus = Bus.MOD,
      value = {Dist.CLIENT}
   )
   public static class FluidsClientSideHandler {
      @SubscribeEvent
      public static void clientSetup(FMLClientSetupEvent event) {
         ItemBlockRenderTypes.setRenderLayer((Fluid)ButtermodModFluids.BUTTERFLUID.get(), RenderType.translucent());
         ItemBlockRenderTypes.setRenderLayer((Fluid)ButtermodModFluids.FLOWING_BUTTERFLUID.get(), RenderType.translucent());
      }
   }
}
