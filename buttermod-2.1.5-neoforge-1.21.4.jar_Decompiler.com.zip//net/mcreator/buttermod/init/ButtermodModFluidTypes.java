package net.mcreator.buttermod.init;

import net.mcreator.buttermod.fluid.types.ButterfluidFluidType;
import net.neoforged.neoforge.fluids.FluidType;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.NeoForgeRegistries;

public class ButtermodModFluidTypes {
   public static final DeferredRegister<FluidType> REGISTRY;
   public static final DeferredHolder<FluidType, FluidType> BUTTERFLUID_TYPE;

   static {
      REGISTRY = DeferredRegister.create(NeoForgeRegistries.FLUID_TYPES, "buttermod");
      BUTTERFLUID_TYPE = REGISTRY.register("butterfluid", () -> {
         return new ButterfluidFluidType();
      });
   }
}
