package net.mcreator.buttermod.init;

import java.util.function.Function;
import net.mcreator.buttermod.item.ButteraxeItem;
import net.mcreator.buttermod.item.ButterdemensionItem;
import net.mcreator.buttermod.item.ButterfluidItem;
import net.mcreator.buttermod.item.ButteringotItem;
import net.mcreator.buttermod.item.ButterpickaxeItem;
import net.mcreator.buttermod.item.ButtershovelItem;
import net.mcreator.buttermod.item.ButterswordItem;
import net.mcreator.buttermod.item.MisterystickItem;
import net.mcreator.buttermod.item.RawbutteroreItem;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.level.block.Block;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredRegister.Items;

public class ButtermodModItems {
   public static final Items REGISTRY = DeferredRegister.createItems("buttermod");
   public static final DeferredItem<Item> BUTTERINGOT = register("butteringot", ButteringotItem::new);
   public static final DeferredItem<Item> BUTTERSWORD = register("buttersword", ButterswordItem::new);
   public static final DeferredItem<Item> BUTTER_BLOCK;
   public static final DeferredItem<Item> BUTTERZOMBIE_SPAWN_EGG;
   public static final DeferredItem<Item> BUTTERPICKAXE;
   public static final DeferredItem<Item> BUTTERAXE;
   public static final DeferredItem<Item> BUTTEROREREAL;
   public static final DeferredItem<Item> BUTTERDEMENSION;
   public static final DeferredItem<Item> BUTTERSHOVEL;
   public static final DeferredItem<Item> MISTERYSTICK;
   public static final DeferredItem<Item> RAWBUTTERORE;
   public static final DeferredItem<Item> BUTTERFLUID_BUCKET;

   private static <I extends Item> DeferredItem<I> register(String name, Function<Properties, ? extends I> supplier) {
      return REGISTRY.registerItem(name, supplier, new Properties());
   }

   private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
      return REGISTRY.registerItem(block.getId().getPath(), (properties) -> {
         return new BlockItem((Block)block.get(), properties);
      }, new Properties());
   }

   static {
      BUTTER_BLOCK = block(ButtermodModBlocks.BUTTER_BLOCK);
      BUTTERZOMBIE_SPAWN_EGG = register("butterzombie_spawn_egg", (properties) -> {
         return new SpawnEggItem((EntityType)ButtermodModEntities.BUTTERZOMBIE.get(), properties);
      });
      BUTTERPICKAXE = register("butterpickaxe", ButterpickaxeItem::new);
      BUTTERAXE = register("butteraxe", ButteraxeItem::new);
      BUTTEROREREAL = block(ButtermodModBlocks.BUTTEROREREAL);
      BUTTERDEMENSION = register("butterdemension", ButterdemensionItem::new);
      BUTTERSHOVEL = register("buttershovel", ButtershovelItem::new);
      MISTERYSTICK = register("misterystick", MisterystickItem::new);
      RAWBUTTERORE = register("rawbutterore", RawbutteroreItem::new);
      BUTTERFLUID_BUCKET = register("butterfluid_bucket", ButterfluidItem::new);
   }
}
