package net.mcreator.buttermod.init;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.block.Block;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ButtermodModTabs {
   public static final DeferredRegister<CreativeModeTab> REGISTRY;
   public static final DeferredHolder<CreativeModeTab, CreativeModeTab> BUTTERMOD;

   static {
      REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, "buttermod");
      BUTTERMOD = REGISTRY.register("buttermod", () -> {
         return CreativeModeTab.builder().title(Component.translatable("item_group.buttermod.buttermod")).icon(() -> {
            return new ItemStack((ItemLike)ButtermodModBlocks.BUTTER_BLOCK.get());
         }).displayItems((parameters, tabData) -> {
            tabData.accept((ItemLike)ButtermodModItems.BUTTERINGOT.get());
            tabData.accept((ItemLike)ButtermodModItems.BUTTERSWORD.get());
            tabData.accept(((Block)ButtermodModBlocks.BUTTER_BLOCK.get()).asItem());
            tabData.accept((ItemLike)ButtermodModItems.BUTTERZOMBIE_SPAWN_EGG.get());
            tabData.accept((ItemLike)ButtermodModItems.BUTTERPICKAXE.get());
            tabData.accept((ItemLike)ButtermodModItems.BUTTERAXE.get());
            tabData.accept(((Block)ButtermodModBlocks.BUTTEROREREAL.get()).asItem());
            tabData.accept((ItemLike)ButtermodModItems.BUTTERDEMENSION.get());
            tabData.accept((ItemLike)ButtermodModItems.BUTTERSHOVEL.get());
            tabData.accept((ItemLike)ButtermodModItems.MISTERYSTICK.get());
            tabData.accept((ItemLike)ButtermodModItems.BUTTERFLUID_BUCKET.get());
         }).build();
      });
   }
}
