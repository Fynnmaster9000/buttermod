package net.mcreator.buttermod.item;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.ShovelItem;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.Item.Properties;

public class ButtershovelItem extends ShovelItem {
   private static final ToolMaterial TOOL_MATERIAL;

   public ButtershovelItem(Properties properties) {
      super(TOOL_MATERIAL, -1.0F, -3.0F, properties.fireResistant());
   }

   static {
      TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_NETHERITE_TOOL, 99999, 99999.0F, 0.0F, 99999, TagKey.create(Registries.ITEM, ResourceLocation.parse("buttermod:buttershovel_repair_items")));
   }
}
