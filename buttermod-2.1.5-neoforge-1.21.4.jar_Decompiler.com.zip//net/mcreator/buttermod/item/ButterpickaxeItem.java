package net.mcreator.buttermod.item;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.Item.Properties;

public class ButterpickaxeItem extends PickaxeItem {
   private static final ToolMaterial TOOL_MATERIAL;

   public ButterpickaxeItem(Properties properties) {
      super(TOOL_MATERIAL, 3.0F, 95.0F, properties.fireResistant());
   }

   static {
      TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_NETHERITE_TOOL, 99999, 100000.0F, 0.0F, 100000, TagKey.create(Registries.ITEM, ResourceLocation.parse("buttermod:butterpickaxe_repair_items")));
   }
}
