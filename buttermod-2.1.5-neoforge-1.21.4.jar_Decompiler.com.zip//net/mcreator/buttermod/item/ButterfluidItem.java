package net.mcreator.buttermod.item;

import net.mcreator.buttermod.init.ButtermodModFluids;
import net.minecraft.world.item.BucketItem;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.level.material.Fluid;

public class ButterfluidItem extends BucketItem {
   public ButterfluidItem(Properties properties) {
      super((Fluid)ButtermodModFluids.BUTTERFLUID.get(), properties.craftRemainder(Items.BUCKET).stacksTo(1).rarity(Rarity.EPIC));
   }
}
