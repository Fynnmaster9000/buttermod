package net.mcreator.buttermod.item;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item.Properties;

public class MisterystickItem extends Item {
   public MisterystickItem(Properties properties) {
      super(properties.rarity(Rarity.EPIC).stacksTo(64).fireResistant());
   }
}
