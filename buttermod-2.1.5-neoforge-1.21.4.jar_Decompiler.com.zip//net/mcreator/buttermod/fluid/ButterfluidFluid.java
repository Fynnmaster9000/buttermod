package net.mcreator.buttermod.fluid;

import net.mcreator.buttermod.init.ButtermodModBlocks;
import net.mcreator.buttermod.init.ButtermodModFluidTypes;
import net.mcreator.buttermod.init.ButtermodModFluids;
import net.mcreator.buttermod.init.ButtermodModItems;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.state.StateDefinition.Builder;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FluidState;
import net.neoforged.neoforge.fluids.BaseFlowingFluid;
import net.neoforged.neoforge.fluids.FluidType;
import net.neoforged.neoforge.fluids.BaseFlowingFluid.Properties;

public abstract class ButterfluidFluid extends BaseFlowingFluid {
   public static final Properties PROPERTIES = (new Properties(() -> {
      return (FluidType)ButtermodModFluidTypes.BUTTERFLUID_TYPE.get();
   }, () -> {
      return (Fluid)ButtermodModFluids.BUTTERFLUID.get();
   }, () -> {
      return (Fluid)ButtermodModFluids.FLOWING_BUTTERFLUID.get();
   })).explosionResistance(100.0F).bucket(() -> {
      return (Item)ButtermodModItems.BUTTERFLUID_BUCKET.get();
   }).block(() -> {
      return (LiquidBlock)ButtermodModBlocks.BUTTERFLUID.get();
   });

   private ButterfluidFluid() {
      super(PROPERTIES);
   }

   public static class Flowing extends ButterfluidFluid {
      protected void createFluidStateDefinition(Builder<Fluid, FluidState> builder) {
         super.createFluidStateDefinition(builder);
         builder.add(new Property[]{LEVEL});
      }

      public int getAmount(FluidState state) {
         return (Integer)state.getValue(LEVEL);
      }

      public boolean isSource(FluidState state) {
         return false;
      }
   }

   public static class Source extends ButterfluidFluid {
      public int getAmount(FluidState state) {
         return 8;
      }

      public boolean isSource(FluidState state) {
         return true;
      }
   }
}
