package net.mcreator.buttermod.fluid.types;

import net.mcreator.buttermod.init.ButtermodModFluidTypes;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.Rarity;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.common.EventBusSubscriber.Bus;
import net.neoforged.neoforge.client.extensions.common.IClientFluidTypeExtensions;
import net.neoforged.neoforge.client.extensions.common.RegisterClientExtensionsEvent;
import net.neoforged.neoforge.common.SoundActions;
import net.neoforged.neoforge.fluids.FluidType;
import net.neoforged.neoforge.fluids.FluidType.Properties;

@EventBusSubscriber(
   bus = Bus.MOD
)
public class ButterfluidFluidType extends FluidType {
   public ButterfluidFluidType() {
      super(Properties.create().fallDistanceModifier(0.0F).canExtinguish(true).supportsBoating(true).canHydrate(true).motionScale(0.007D).rarity(Rarity.EPIC).sound(SoundActions.BUCKET_FILL, SoundEvents.BUCKET_FILL).sound(SoundActions.BUCKET_EMPTY, SoundEvents.BUCKET_EMPTY).sound(SoundActions.FLUID_VAPORIZE, SoundEvents.FIRE_EXTINGUISH));
   }

   @SubscribeEvent
   public static void registerFluidTypeExtensions(RegisterClientExtensionsEvent event) {
      event.registerFluidType(new IClientFluidTypeExtensions() {
         private static final ResourceLocation STILL_TEXTURE = ResourceLocation.parse("minecraft:block/honey_block_side");
         private static final ResourceLocation FLOWING_TEXTURE = ResourceLocation.parse("minecraft:block/honey_block_top");

         public ResourceLocation getStillTexture() {
            return STILL_TEXTURE;
         }

         public ResourceLocation getFlowingTexture() {
            return FLOWING_TEXTURE;
         }
      }, new FluidType[]{(FluidType)ButtermodModFluidTypes.BUTTERFLUID_TYPE.get()});
   }
}
